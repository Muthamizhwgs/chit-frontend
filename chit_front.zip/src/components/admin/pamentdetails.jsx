import React from "react";

const data = [
  {
    id: 1,
    date: "05-07-2023",
    name: "KKR travels",
    items: [
      { group: "10 Lakhs B", month: 8, amount: 120000, amountToBePaid: 45500 },
      { group: "10 Lakhs A", month: 14, amount: 70000, amountToBePaid: 48000 },
    ],
    amount: 96000,
    balance: 45599,
    total: 50000,
  },
  {
    id: 1,
    date: "05-07-2023",
    name: "KKR travels",
    items: [
      { group: "10 Lakhs B", month: 8, amount: 120000, amountToBePaid: 45500 },
      { group: "10 Lakhs A", month: 14, amount: 70000, amountToBePaid: 48000 },
    ],
    amount: 96000,
    balance: 45599,
    total: 50000,
  },
  {
    id: 1,
    date: "05-07-2023",
    name: "KKR travels",
    items: [
      { group: "10 Lakhs B", month: 8, amount: 120000, amountToBePaid: 45500 },
      { group: "10 Lakhs A", month: 14, amount: 70000, amountToBePaid: 48000 },
    ],
    amount: 96000,
    balance: 45599,
    total: 50000,
  },
  {
    id: 1,
    date: "05-07-2023",
    name: "KKR travels",
    items: [
      { group: "10 Lakhs B", month: 8, amount: 120000, amountToBePaid: 45500 },
      { group: "10 Lakhs A", month: 14, amount: 70000, amountToBePaid: 48000 },
    ],
    amount: 96000,
    balance: 45599,
    total: 50000,
  },
  {
    id: 1,
    date: "05-07-2023",
    name: "KKR travels",
    items: [
      { group: "10 Lakhs B", month: 8, amount: 120000, amountToBePaid: 45500 },
      { group: "10 Lakhs A", month: 14, amount: 70000, amountToBePaid: 48000 },
    ],
    amount: 96000,
    balance: 45599,
    total: 50000,
  },
];

const Pamentdetails = () => {
  return (
    <div>
      {data.map((entry) => (
        <Card key={entry.id} data={entry} />
      ))}
    </div>
  );
};

const Card = ({ data, index }) => {
  return (
    <div className="bg-gray-100 p-4 m-4 rounded-lg shadow-md w-80">
    <p className="text-lg font-bold">{data.name}</p>
    <p className="text-sm">{data.date}</p>
    <div className="mt-4">
      {data.items.map((item, i) => (
        <div key={i} className="mb-2">
          <p><span className="font-semibold">Group:</span> {item.group}</p>
          <p><span className="font-semibold">Month:</span> {item.month}</p>
          <p><span className="font-semibold">Amount:</span> {item.amount}</p>
          <p><span className="font-semibold">Amount to be Paid:</span> {item.amountToBePaid}</p>
        </div>
      ))}
    </div>
    <p className="mt-4"><span className="font-semibold">Amount:</span> {data.amount}</p>
    <p><span className="font-semibold">Balance:</span> {data.balance}</p>
    <p><span className="font-semibold">Total:</span> {data.total}</p>
  </div>
  );
};

export default Pamentdetails;